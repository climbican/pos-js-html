class ReceiptPrinterInfo {
	buttonPressed = false;
    online = true;
    coverOpened = false;
    paperLoaded = true;
    paperLow = false;
}

export default ReceiptPrinterInfo;