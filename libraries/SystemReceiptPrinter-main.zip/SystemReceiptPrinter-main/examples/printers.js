import SystemReceiptPrinter from "../src/main.js";

console.log(
    SystemReceiptPrinter.getPrinters()
);
